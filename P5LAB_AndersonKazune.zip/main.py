#CTI-110
#P5LAB - Leap Year(function)
#Kazune Anderson
#4/5/2023

print('This program takes in a year from a user and calculates the number of days in February for that year')
print()

def days_in_feb(user_year):
    
    #Default the days in February to 28
    days = 28
    
    #For the leap year
    #user_year must be divisible by 400 
    #user_year must be divisible by 4, but not by 100
    if (user_year % 400 == 0) or ((user_year % 4 == 0) and (user_year % 100 != 0)):
        days = 29               
    return days

if __name__ == '__main__':
    while(True):
        entered_year = int(input('Please enter year or 0 to terminate: '))
        if entered_year == 0:
            break
        print(f'{entered_year} has {days_in_feb(entered_year)} days in February.')
        print()
