#CTI-110
#P3LAB - List
#Kazune Anderson
#2/27/2023

print("This program will calculate to check if a year is a leap year or not")
print()

#Ask user to enter a year
year = int(input("Please enter a year:"))

#1)The year must be divisile by 4
if(year % 4 == 0) and (year % 100 != 0):
   print(f'{year} - leap year')

#2)If the year is a centry year, the year must be evenly divisible by 400.
elif(year % 400 == 0) and (year % 100 == 0):
   print(f'{year} - leap year')

# Not true 1) or 2)
else:
    print(f'{year} - not a leap year')