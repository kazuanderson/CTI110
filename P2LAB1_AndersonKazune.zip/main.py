#Feb22,2023
#CTI-110P2HW2-Driving Costs
#Anderson_Kazune

print("This program calculates and displays Driving Costs ")
print()

#Ask user to enter their milage per gallon of their car
milesPerGallon = float(input("Please enter how many milage per gallon of your car: "))
print()

#Ask user to enter their cost of gas per gallon
dollarsPerGallon = float(input("Please Enter your cost of gas per gallon : "))
print()

print(f'You entered milage per gallon of your car is {milesPerGallon} and your cost of gas per gallon is {dollarsPerGallon}')
print()

gasCost = dollarsPerGallon / milesPerGallon

totalGasCost20m = gasCost * 20

totalGasCost75m = gasCost * 75

totalGasCost500m = gasCost * 500

print(f'Your total Gas cost is\n\t20  miles:  {totalGasCost20m:.2f} \n\t75  miles: {totalGasCost75m:.2f} \n\t500 miles: {totalGasCost500m:.2f}')