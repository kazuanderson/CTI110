#CTI-110
#P4LAB2 - Output Range with increment of 5
#Kazune Anderson
#3/22/2023

print("This program uses two integers input by a user to execute the output of the first integer and subsequent increments of 5 as long as the value is less than or equal to the second integer. ")
print()

#Ask user to enter first integer
num_1 = int(input("Please Enter your first integer: "))
print()
#Ask user to enter second integer
num_2 = int(input("Please Enter your second integer: "))
print()

#Excute the loop program
if num_1 <= num_2:
   while num_1 <= num_2:
        print(num_1, end=' ')
        num_1 += 5
   print()
else:
    print("Second integer can\'t be less than the first.")
