userName = input("Please Enter your name : ")
print("Hello " + userName + " " + "Welcome to CIT 110!")

