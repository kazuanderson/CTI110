#Feb25,2023
#CTI-110P2LAB2-SimpleStatistics
#Anderson_Kazune

print("This program calculates and displays your product and average as integers (rounded), then as floating-point numbers ")
print()


#Ask user to enter their 4 floating-point number

num1 = float(input("Please enter 1st decimal point number you like."))
print()

num2 = float(input("Please enter 2nd decimal point number you like."))
print()

num3 = float(input("Please enter 3rd decimal point number you like."))
print()

num4 = float(input("Please enter 4th decimal point number you like."))
print()

average = (num1 + num2 + num3 + num4) / 4

your_value = num1 * num2 * num3 * num4

print(f'your product as integers is {your_value:.0f} and your average as integers is {average:.0f}')
print(f'your product as floating-point numbers is {your_value:.3f} and your average as floating-point numbers is {average:.3f}')